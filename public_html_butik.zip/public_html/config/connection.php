<?php
$connect = mysqli_connect("localhost", "id20363535_butik", "PMQ~)Qp^7Pr[l]Cw", "id20363535_db_butik");

if($connect){
    echo "konek";
}else{
    echo "tidak konek";
}
